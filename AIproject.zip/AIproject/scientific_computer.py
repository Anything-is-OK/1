from PIL import Image, ImageTk
import tkinter as tk



# root = tk.Tk()
# text = tk.Text(root)
# image = Image.open("Group3.jpg")
# photo = ImageTk.PhotoImage(image)
# text.image_create(tk.END, image=photo)#用这个方法创建一个图片对象，并插入到“END”的位置
# text.pack()
# root.mainloop()

# root = tk.Tk()
# root.title("游 戏 抽 卡 概 率 计 算 器")
# image = Image.open("Group3.jpg")
# image = image.resize((300, 200))
# photo = ImageTk.PhotoImage(image)
#
# gacha = tk.Label(root, text="当前抽卡次数：",image=photo)
# gacha_label = tk.Label(root, text="当前抽卡次数：")
# gacha_label.grid(column=1, row=0, columnspan=2, padx=10, pady=10)
# pity_count_label = tk.Label(root, text="当前保底次数:")
# root.mainloop()

root = tk.Tk()
#加载图片
image = Image.open("Group3.jpg")
photo = ImageTk.PhotoImage(image)
#创建Label对象
label = tk.Label(root, image=photo)
#显示控件
label.pack()
root.mainloop()