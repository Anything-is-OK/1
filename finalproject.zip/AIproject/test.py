import random
import time


#                    大小保底     原石         结晶           纠缠         星辉        当前抽数
def calculate_pity(gacha_type, primogems, crystals, intertwined_fate, glitter, stardust_count):
    # 计算总抽数
    total_pulls = int((primogems + crystals) / 160 + intertwined_fate + glitter / 5)
    # 计算剩余抽数
    residue = total_pulls
    # 根据保底类型计算UP角色概率和保底抽数
    if gacha_type == "小保底":
        up_prob = 0.003

    else:
        up_prob = 0.006
    # 五星数量
    five_star_count = 0
    # 星辉剩余数量
    glitter = glitter % 5
    # 开始抽卡
    while residue >= 1:
        # 可抽数减1
        residue -= 1
        # 步数+1
        stardust_count += 1
        if stardust_count == 180:
            # 大到保底
            five_star_count += 1
            glitter += 10
            stardust_count = 0  # 抽数清0
            # print("大保底")
        elif stardust_count == 90:
            if random.random() < 0.5:
                # 抽到UP角色
                glitter += 10  # 星辉加10
                five_star_count += 1  # 五星加1
                stardust_count = 0  # 抽数清0
                # print("抽中小保底")
        if stardust_count % 10 == 0:
            glitter += 2
            # print("新辉+2")
        if random.random() < up_prob:
            # 抽到五星角色
            five_star_count += 1
            glitter += 10  # 星辉加10
            five_star_count += 1  # 五星加1
            stardust_count = 0  # 抽数清0
            # print("抽中五星")
        # else:
            # print("什么都没有")

        # 计算额外抽数
        extra_pulls = int(glitter / 5)
        residue += extra_pulls
        total_pulls += extra_pulls
        # print("==============================================")
        # print("星辉数量：", glitter)
        # print("额外抽数:", extra_pulls)
        # print("总抽数量:", total_pulls)
        # print("当前抽数", residue)
        # print("五星卡片:", five_star_count)
        # print("当前步数", stardust_count)
        glitter = glitter % 5
    # 返回结果：五星，总抽数
    return five_star_count, int(total_pulls)


# 返回五星次数和总抽数。                          大小保低    原石  结晶  纠缠 星辉 当前抽数
# five_star_count, total_pulls = calculate_pity("小保底", 16000, 10, 10, 10, 10)
# print(five_star_count, total_pulls)
t = 0 # 总出金次数
#                                大小保底           原石         结晶           纠缠         星辉        当前抽数
for i in range(0,10000):
    r1,r2 = calculate_pity("小保底",1111,1111,111,111,11)
    if r1 >=1:
        t = t + 1

x = t/10000
print("出金次数",t,"，出金概率",x)
