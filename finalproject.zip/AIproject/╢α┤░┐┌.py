import PySimpleGUI as sg
from math import sin,cos,tan,exp,log,log10,pow

#######说明#######
# win_basic为四则运算窗口，win_sc为科学计算器窗口，win_common为通用抽卡概率计算器
# 计算器按钮设置函数
def button(text):
    return sg.B(text,pad=(2,2),size=(5,2),font=('黑体',18),button_color='black')
# 四则运算计算器窗口设置
char_list = ['AC','(',')','%','1','2','3','+','4','5','6','-','7','8','9','X','0','.','=','÷']
layout_basic = [
    [sg.Button("科学计算器",size=(12,1))],
    [sg.Button("通用抽卡计算器",size=(12,1))],
    [sg.T('',key='-SHOW-')],
    [sg.In('',size=(14,2),font=('黑体',28),key='-INPUT-')],
    [button(i) for i in ['AC','(',')','%']],
    [button(i) for i in '123+'],
    [button(i) for i in '456-'],
    [button(i) for i in '789X'],
    [button(i) for i in '0.=÷']
]
win_basic = sg.Window("四则运算计算器", layout_basic, default_element_size=(10, 1))

win_sc_active = False         # 科学计算器界面显示信号
win_Common_active = False     # 通用抽卡界面显示信号
while True:
    ev_basic,vals_basic = win_basic.read(timeout=100)
    win_basic_active = True
    if ev_basic == sg.WIN_CLOSED or ev_basic == 'Exit':
        break
    # 四则运算计算器计算规则设置
    # 无需改变的字符
    if ev_basic in list('0123456789+-().'):
        win_basic['-INPUT-'].update(vals_basic['-INPUT-'] + ev_basic)
        win_basic['-SHOW-'].update('')  # 若不加此行，输入有误提示将一直存在
    # 需要改变的字符
    if ev_basic == 'X':
        win_basic['-INPUT-'].update(vals_basic['-INPUT-'] + '*')
        win_basic['-SHOW-'].update('')
    if ev_basic == '÷':
        win_basic['-INPUT-'].update(vals_basic['-INPUT-'] + '/')
        win_basic['-SHOW-'].update('')
    if ev_basic == '%':
        # 若直接按%，会直接结束程序，因此设置报错提示
        try:
            win_basic['-INPUT-'].update(eval(vals_basic['-INPUT-'] + '/100'))  # 百分号需要计算
        except:
            win_basic['-INPUT-'].update('')
            win_basic['-SHOW-'].update('输入错误')
    if ev_basic == '=':
        # 等号与%处理方法相同
        try:
            win_basic['-INPUT-'].update(eval(vals_basic['-INPUT-']))
        except:
            win_basic['-INPUT-'].update('')
            win_basic['-SHOW-'].update('输入错误')
    if ev_basic == 'AC':
        win_basic['-INPUT-'].update('')
        win_basic['-SHOW-'].update('')
    # 显示科学计算器窗口
    if ev_basic =="科学计算器" and not win_sc_active:
        win_sc_active = True
        win_basic.hide()
        # 科学计算器窗口设置
        layout_sc = [
            [sg.T('', key='-SHOW-')],
            [sg.In('', size=(26, 2), font=('黑体', 28), key='-INPUT-')],
            [sg.B(i, pad=(0, 2), size=(10, 2), font=('黑体', 18), button_color='black') for i in ['AC', '(', ')', '%']],
            [button(i) for i in ['sin', 'cos', 'tan', '1', '2', '3', '+']],
            [button(i) for i in ['cot', 'sec', 'csc', '4', '5', '6', '-']],
            [button(i) for i in ['e', 'ln', 'log₁₀', '7', '8', '9', 'X']],
            [button(i) for i in ['1/x', 'x²', 'x³', '0', '.', '=', '÷']]
        ]
        win_sc = sg.Window("科学计算器", layout_sc)
        while True:
            ev_sc, vals_sc = win_sc.read(timeout=100)
            if ev_sc == sg.WIN_CLOSED or ev_sc == 'Exit':
                win_sc_active = False
                win_sc.close()
                win_basic.UnHide()
                break
                # 无需改变的字符
            if ev_sc in list('0123456789+-().'):
                win_sc['-INPUT-'].update(vals_sc['-INPUT-'] + ev_sc)
                win_sc['-SHOW-'].update('')  # 若不加此行，输入有误提示将一直存在
            # 需要改变的字符
            if ev_sc == 'X':
                win_sc['-INPUT-'].update(vals_sc['-INPUT-'] + '*')
                win_sc['-SHOW-'].update('')
            if ev_sc == '÷':
                win_sc['-INPUT-'].update(vals_sc['-INPUT-'] + '/')
                win_sc['-SHOW-'].update('')
            if ev_sc == '%':
                # 若直接按%，会直接结束程序，因此设置报错提示
                try:
                    win_sc['-INPUT-'].update(eval(vals_sc['-INPUT-'] + '/100'))  # 百分号需要计算
                except:
                    win_sc['-INPUT-'].update('')
                    win_sc['-SHOW-'].update('输入错误')
            if ev_sc == '=':
                # 等号与%处理方法相同
                try:
                    win_sc['-INPUT-'].update(eval(vals_sc['-INPUT-']))
                except:
                    win_sc['-INPUT-'].update('')
                    win_sc['-SHOW-'].update('输入错误')
            if ev_sc == 'sin':
                win_sc['-INPUT-'].update(vals_sc['-INPUT-'] + 'sin(')
                win_sc['-SHOW-'].update('')
            if ev_sc == 'cos':
                win_sc['-INPUT-'].update(vals_sc['-INPUT-'] + 'cos(')
                win_sc['-SHOW-'].update('')
            if ev_sc == 'tan':
                win_sc['-INPUT-'].update(vals_sc['-INPUT-'] + 'tan(')
                win_sc['-SHOW-'].update('')
            if ev_sc == 'cot':
                win_sc['-INPUT-'].update(vals_sc['-INPUT-'] + '1/tan(')
                win_sc['-SHOW-'].update('')
            if ev_sc == 'sec':
                win_sc['-INPUT-'].update(vals_sc['-INPUT-'] + '1/cos(')
                win_sc['-SHOW-'].update('')
            if ev_sc == 'csc':
                win_sc['-INPUT-'].update(vals_sc['-INPUT-'] + '1/sin(')
                win_sc['-SHOW-'].update('')
            if ev_sc == 'e':
                win_sc['-INPUT-'].update(vals_sc['-INPUT-'] + 'exp(')
                win_sc['-SHOW-'].update('')
            if ev_sc == 'ln':
                win_sc['-INPUT-'].update(vals_sc['-INPUT-'] + 'log(')
                win_sc['-SHOW-'].update('')
            if ev_sc == 'log₁₀':
                win_sc['-INPUT-'].update(vals_sc['-INPUT-'] + 'log10(')
                win_sc['-SHOW-'].update('')
            if ev_sc == '1/x':
                win_sc['-INPUT-'].update(vals_sc['-INPUT-'] + '1/(')
                win_sc['-SHOW-'].update('')
            if ev_sc == 'x²':
                win_sc['-INPUT-'].update(vals_sc['-INPUT-'] + '**2')
                win_sc['-SHOW-'].update('')
            if ev_sc == 'x³':
                win_sc['-INPUT-'].update(vals_sc['-INPUT-'] + '**3')
                win_sc['-SHOW-'].update('')
            if ev_sc == 'AC':
                win_sc['-INPUT-'].update('')
                win_sc['-SHOW-'].update('')
    if ev_basic =="通用抽卡计算器" and not win_Common_active:
        win_Common_active = True
        win_basic.hide()
        layout_common = [
            [sg.Button("win2")],
            [sg.Input("123123", key="-13-")]
        ]
        win_Common = sg.Window("通用抽卡计算器", layout_common, default_element_size=(10, 1))
        while True:
            ev_common, vals_common = win_Common.read(timeout=100)
            if ev_common == sg.WIN_CLOSED or ev_common == 'Exit':
                win_Common_active = False
                win_Common.close()
                win_basic.UnHide()
                break
win_basic.close()